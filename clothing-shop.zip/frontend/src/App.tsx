﻿import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import './App.css'
import './safe-header.css'
import HomePage from './pages/HomePage'
import AdminPanel from './pages/AdminPanel'
import ProductsPage from './pages/ProductsPage'
import CartPage from './pages/CartPage'
import CheckoutPage from './pages/CheckoutPage'
import AboutPage from './pages/AboutPage'
import PrivacyPolicyPage from './pages/PrivacyPolicyPage'
import TermsPage from './pages/TermsPage'
import MaintenancePage from './pages/MaintenancePage.tsx'
import CookieConsent from './components/CookieConsent'
import visaLogo from './assets/visa.svg'
import mcLogo from './assets/mastercard.svg'
import paypalLogo from './assets/paypal.svg'
import { useCart } from './utils/useCart'

function App() {
  const { cart } = useCart()
  const cartCount = cart.length
  const [social, setSocial] = useState({ instagram: '#', facebook: '#', twitter: '#' })
  const [maintenance, setMaintenance] = useState<{ enabled: boolean; title: string; message: string }>({ enabled:false, title:"We'll be back soon", message:'We are performing scheduled maintenance. Please check back shortly.' })
  const [anpc, setAnpc] = useState<{ url: string; icon: string; text: string }>({ url: '', icon: '', text: 'ANPC' })

  const isHttpsUrl = (val?: string) => {
    if (!val) return false
    try {
      const u = new URL(val)
      return u.protocol === 'https:'
    } catch {
      return false
    }
  }

  const loadSocial = () => {
    try {
      const instagram = localStorage.getItem('social.instagram') || '#'
      const facebook = localStorage.getItem('social.facebook') || '#'
      const twitter = localStorage.getItem('social.twitter') || '#'
      setSocial({ instagram, facebook, twitter })
    } catch {
      setSocial({ instagram: '#', facebook: '#', twitter: '#' })
    }
  }

  useEffect(() => {
    loadSocial()
    const onUpdate = () => loadSocial()
    window.addEventListener('socialLinksUpdated', onUpdate as any)
    return () => window.removeEventListener('socialLinksUpdated', onUpdate as any)
  }, [])

  const loadAnpc = () => {
    try {
      const url = localStorage.getItem('anpc.url') || ''
      const icon = localStorage.getItem('anpc.icon') || ''
      const text = localStorage.getItem('anpc.text') || 'ANPC'
      setAnpc({ url, icon, text })
    } catch {
      setAnpc({ url: '', icon: '', text: 'ANPC' })
    }
  }

  useEffect(() => {
    loadAnpc()
    const onStorage = (e: StorageEvent) => {
      if (e.key && e.key.startsWith('anpc.')) loadAnpc()
    }
    const onCustom = () => loadAnpc()
    window.addEventListener('storage', onStorage)
    window.addEventListener('anpcUpdated', onCustom as any)
    return () => {
      window.removeEventListener('storage', onStorage)
      window.removeEventListener('anpcUpdated', onCustom as any)
    }
  }, [])

  useEffect(() => {
    const loadMaint = () => {
      try {
        const enabled = (localStorage.getItem('maintenance.enabled') || 'false') === 'true'
        const title = localStorage.getItem('maintenance.title') || "We'll be back soon"
        const message = localStorage.getItem('maintenance.message') || 'We are performing scheduled maintenance. Please check back shortly.'
        setMaintenance({ enabled, title, message })
      } catch {
        setMaintenance(m=>({ ...m, enabled:false }))
      }
    }
    loadMaint()
    const onUpdate = () => loadMaint()
    window.addEventListener('maintenanceUpdated', onUpdate as any)
    return () => window.removeEventListener('maintenanceUpdated', onUpdate as any)
  }, [])

  return (
    <Router>
      <div className="app-container">
        <nav className="navbar">
          <div className="nav-container">
            <Link to="/" className="logo">
              <span className="logo-icon">🛡️</span>
              <span className="logo-text">GVNG</span>
            </Link>
            <div className="nav-menu">
              <Link to="/" className="nav-link">HOME</Link>
              <Link to="/products" className="nav-link">COLLECTION</Link>
              <Link to="/cart" className="nav-link cart-link">
                CART
                {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
              </Link>
              {/** Admin link removed per request; use floating gear instead */}
            </div>
            <button className="menu-toggle">☰</button>
          </div>
        </nav>

        <CookieConsent />

        <main className="main-content">
          <Routes>
            <Route path="/" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <HomePage />} />
            <Route path="/products" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <ProductsPage />} />
            <Route path="/cart" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <CartPage />} />
            <Route path="/about" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <AboutPage />} />
            <Route path="/privacy" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <PrivacyPolicyPage />} />
            <Route path="/terms" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <TermsPage />} />
            <Route path="/checkout" element={maintenance.enabled ? <MaintenancePage title={maintenance.title} message={maintenance.message} /> : <CheckoutPage />} />
            <Route path="/maintenance" element={<MaintenancePage title={maintenance.title} message={maintenance.message} />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </main>

        <footer className="footer">
          <div className="footer-container">
            <div className="footer-section">
              <h4>ABOUT</h4>
              <p>Premium quality clothing and accessories for the modern lifestyle.</p>
              <div className="social-links" style={{ display:'flex', gap:12 }}>
                {isHttpsUrl(social.instagram) && (
                  <a href={social.instagram} target="_blank" rel="noreferrer" style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><path d="M16.5 7.5h.01"/><circle cx="12" cy="12" r="4.2"/></svg>
                    Instagram
                  </a>
                )}
                {isHttpsUrl(social.facebook) && (
                  <a href={social.facebook} target="_blank" rel="noreferrer" style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06C2 17.08 5.66 21.2 10.44 22v-7.02H7.9v-2.92h2.54V9.41c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.23.2 2.23.2v2.45h-1.26c-1.24 0-1.62.77-1.62 1.56v1.87h2.77l-.44 2.92h-2.33V22C18.34 21.2 22 17.08 22 12.06Z"/></svg>
                    Facebook
                  </a>
                )}
                {isHttpsUrl(social.twitter) && (
                  <a href={social.twitter} target="_blank" rel="noreferrer" style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M19.633 7.997c.013.176.013.353.013.53 0 5.39-4.103 11.6-11.6 11.6-2.307 0-4.45-.676-6.256-1.84.325.039.637.052.975.052 1.907 0 3.663-.65 5.064-1.752-1.786-.039-3.292-1.21-3.812-2.827.25.039.5.065.763.065.364 0 .728-.052 1.066-.14-1.867-.377-3.274-2.02-3.274-4.003v-.052c.537.299 1.16.484 1.82.511-1.08-.724-1.793-1.954-1.793-3.35 0-.741.195-1.417.537-2.008 1.96 2.406 4.887 3.983 8.182 4.16-.064-.298-.103-.61-.103-.922 0-2.236 1.82-4.055 4.068-4.055 1.17 0 2.229.484 2.972 1.262.922-.176 1.806-.52 2.589-.987-.303.948-.948 1.742-1.793 2.243.818-.102 1.6-.312 2.327-.623-.537.804-1.21 1.5-1.987 2.07Z"/></svg>
                    Twitter
                  </a>
                )}
              </div>
            </div>
            <div className="footer-section">
              <h4>CUSTOMER CARE</h4>
              <ul><li><a href="#">Contact Us</a></li><li><a href="#">Shipping Info</a></li><li><a href="#">Returns Policy</a></li><li><a href="#">FAQ</a></li></ul>
            </div>
            <div className="footer-section">
              <h4>INFORMATION</h4>
              <ul><li><Link to="/about">About Us</Link></li><li><Link to="/privacy">Privacy Policy</Link></li><li><Link to="/terms">Terms & Conditions</Link></li><li><a href="#">Size Guide</a></li></ul>
            </div>
            <div className="footer-section">
              <h4>CONTACT</h4>
              <p>Email: info@gvng.com</p>
              <p>Phone: 0000</p>
              <p>Address: 123 Fashion St, NY 10001</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2024 GVNG. All rights reserved.</p>
            <div className="payment-methods" style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
              <img src={visaLogo} alt="Visa" height={24} />
              <img src={mcLogo} alt="Mastercard" height={24} />
              <img src={paypalLogo} alt="PayPal" height={24} />
              {(() => {
                const hasValidUrl = !!anpc.url && (anpc.url.startsWith('http://') || anpc.url.startsWith('https://'))
                const href = hasValidUrl ? anpc.url : 'https://anpc.ro'
                const hasIcon = !!anpc.icon && (anpc.icon.startsWith('http://') || anpc.icon.startsWith('https://') || anpc.icon.startsWith('data:'))
                const src = hasIcon ? anpc.icon : '/anpc-sal.svg'
                const content = <img src={src} alt={anpc.text || 'ANPC'} height={24} style={{ display:'inline-block' }} />
                return (
                  <a href={href} title={anpc.text || 'ANPC'} target="_blank" rel="noreferrer" style={{ display:'inline-flex', alignItems:'center' }}>
                    {content}
                  </a>
                )
              })()}
            </div>
          </div>
        </footer>
        {/* Floating admin gear */}
        <Link
          to="/admin"
          title="Admin"
          aria-label="Admin"
          style={{
            position: 'fixed',
            right: 20,
            bottom: 20,
            width: 54,
            height: 54,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'rgba(27,27,27,0.92)',
            color: '#CFFF04',
            border: '2px solid #333',
            borderRadius: '50%',
            boxShadow: '0 0 16px 2px #CFFF0480, 0 6px 18px rgba(0,0,0,0.35)',
            zIndex: 3000,
            transition: 'box-shadow 0.25s, background 0.25s, color 0.25s',
            cursor: 'pointer',
          }}
          onMouseOver={e => {
            (e.currentTarget as HTMLElement).style.boxShadow = '0 0 24px 6px #CFFF04, 0 6px 18px rgba(0,0,0,0.45)';
            (e.currentTarget as HTMLElement).style.background = 'rgba(27,27,27,1)';
            (e.currentTarget as HTMLElement).style.color = '#E6FF00';
          }}
          onMouseOut={e => {
            (e.currentTarget as HTMLElement).style.boxShadow = '0 0 16px 2px #CFFF0480, 0 6px 18px rgba(0,0,0,0.35)';
            (e.currentTarget as HTMLElement).style.background = 'rgba(27,27,27,0.92)';
            (e.currentTarget as HTMLElement).style.color = '#CFFF04';
          }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M12 15.5A3.5 3.5 0 1 0 12 8.5a3.5 3.5 0 0 0 0 7z"/>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .66.26 1.3.73 1.77.47.47 1.11.73 1.77.73H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
          </svg>
        </Link>
      </div>
    </Router>
  )
}

export default App
 
