import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { Product } from './models/Product';

dotenv.config();

const sampleProducts = [
  {
    name: "Classic Black T-Shirt",
    description: "Comfortable and versatile black cotton t-shirt, perfect for everyday wear",
    price: 24.99,
    category: "men",
    size: ["S", "M", "L", "XL", "XXL"],
    color: ["Black", "White", "Gray"],
    stock: 50,
    image: "https://via.placeholder.com/300x400?text=Black+T-Shirt",
    images: ["https://via.placeholder.com/300x400?text=Black+T-Shirt+1"]
  },
  {
    name: "Women's White Blouse",
    description: "Elegant white blouse suitable for both casual and professional settings",
    price: 39.99,
    category: "women",
    size: ["XS", "S", "M", "L", "XL"],
    color: ["White", "Beige"],
    stock: 35,
    image: "https://via.placeholder.com/300x400?text=White+Blouse",
    images: ["https://via.placeholder.com/300x400?text=White+Blouse+1"]
  },
  {
    name: "Kids' Colorful Hoodie",
    description: "Fun and colorful hoodie for kids, perfect for playtime and casual outings",
    price: 34.99,
    category: "kids",
    size: ["2T", "3T", "4T", "5T", "6T"],
    color: ["Blue", "Pink", "Yellow"],
    stock: 40,
    image: "https://via.placeholder.com/300x400?text=Kids+Hoodie",
    images: ["https://via.placeholder.com/300x400?text=Kids+Hoodie+1"]
  },
  {
    name: "Denim Blue Jeans",
    description: "Classic denim jeans with a comfortable fit for all occasions",
    price: 59.99,
    category: "men",
    size: ["28", "30", "32", "34", "36"],
    color: ["Dark Blue", "Light Blue", "Black"],
    stock: 60,
    image: "https://via.placeholder.com/300x400?text=Denim+Jeans",
    images: ["https://via.placeholder.com/300x400?text=Denim+Jeans+1"]
  },
  {
    name: "Women's Summer Dress",
    description: "Lightweight and breathable summer dress, ideal for warm weather",
    price: 49.99,
    category: "women",
    size: ["XS", "S", "M", "L", "XL"],
    color: ["Red", "Floral", "Navy"],
    stock: 45,
    image: "https://via.placeholder.com/300x400?text=Summer+Dress",
    images: ["https://via.placeholder.com/300x400?text=Summer+Dress+1"]
  },
  {
    name: "Sports Socks Pack",
    description: "Set of 6 comfortable sports socks with excellent cushioning",
    price: 19.99,
    category: "accessories",
    size: ["One Size"],
    color: ["Black", "White", "Gray"],
    stock: 100,
    image: "https://via.placeholder.com/300x400?text=Sports+Socks",
    images: ["https://via.placeholder.com/300x400?text=Sports+Socks+1"]
  },
  {
    name: "Canvas Sneakers",
    description: "Stylish and comfortable canvas sneakers for everyday wear",
    price: 54.99,
    category: "accessories",
    size: ["6", "7", "8", "9", "10", "11", "12"],
    color: ["White", "Black", "Blue"],
    stock: 30,
    image: "https://via.placeholder.com/300x400?text=Canvas+Sneakers",
    images: ["https://via.placeholder.com/300x400?text=Canvas+Sneakers+1"]
  },
  {
    name: "Leather Jacket",
    description: "Premium leather jacket that adds style and warmth to any outfit",
    price: 149.99,
    category: "men",
    size: ["S", "M", "L", "XL"],
    color: ["Black", "Brown"],
    stock: 15,
    image: "https://via.placeholder.com/300x400?text=Leather+Jacket",
    images: ["https://via.placeholder.com/300x400?text=Leather+Jacket+1"]
  },
  {
    name: "Wool Scarf",
    description: "Soft and warm wool scarf perfect for winter months",
    price: 29.99,
    category: "accessories",
    size: ["One Size"],
    color: ["Red", "Black", "Gray", "Navy"],
    stock: 50,
    image: "https://via.placeholder.com/300x400?text=Wool+Scarf",
    images: ["https://via.placeholder.com/300x400?text=Wool+Scarf+1"]
  },
  {
    name: "Women's Yoga Pants",
    description: "High-waist yoga pants with excellent stretch and comfort",
    price: 64.99,
    category: "women",
    size: ["XS", "S", "M", "L", "XL"],
    color: ["Black", "Gray", "Navy"],
    stock: 40,
    image: "https://via.placeholder.com/300x400?text=Yoga+Pants",
    images: ["https://via.placeholder.com/300x400?text=Yoga+Pants+1"]
  }
];

async function seedDatabase() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/clothing-shop';
    
    console.log('Connecting to MongoDB...');
    await mongoose.connect(mongoUri);
    
    console.log('Clearing existing products...');
    await Product.deleteMany({});
    
    console.log('Seeding database with sample products...');
    await Product.insertMany(sampleProducts);
    
    console.log(`✅ Successfully seeded ${sampleProducts.length} products!`);
    console.log('Disconnecting from MongoDB...');
    await mongoose.disconnect();
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
